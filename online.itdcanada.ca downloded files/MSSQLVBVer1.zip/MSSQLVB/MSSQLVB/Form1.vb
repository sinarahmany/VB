﻿Public Class Form1
    Dim cn As New OleDb.OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim ds As New DataSet
    Dim Maxrecord As Integer
    Dim CurrentRow As Integer
    'create an array of datarows 
    ' so the result of select method can live in this array
    Dim foundRows() As Data.DataRow
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BooksNewDataSet.BooksTable' table. You can move, or remove it, as needed.
        Me.BooksTableTableAdapter1.Fill(Me.BooksNewDataSet.BooksTable)
        'TODO: This line of code loads data into the 'BooksDataSet.BooksTable' table. You can move, or remove it, as needed.
        'Me.BooksTableTableAdapter.Fill(Me.BooksDataSet.BooksTable)

        cn.ConnectionString = "Provider = SQLNCLI11;Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Downloads\MSSQLVB\MSSQLVB\BooksNew.mdf;Integrated Security=SSPI"
        cn.Open()
        'My Connection is Established
        Dim SqlStr As String
        SqlStr = "Select * from Bookstable"
        da = New OleDb.OleDbDataAdapter(SqlStr, cn)
        da.Fill(ds, "Bookstable")
        Maxrecord = ds.Tables("Bookstable").Rows.Count - 1
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CurrentRow = 0
        Call ShowRecord(CurrentRow)
    End Sub
    Public Sub ShowRecord(ByVal ThisRow As Integer)
        TextBox1.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(0)
        TextBox2.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(1)
        TextBox3.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(2)
        TextBox4.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(3)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CurrentRow = Maxrecord
        ShowRecord(CurrentRow)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        CurrentRow = CurrentRow + 1
        If CurrentRow = Maxrecord + 1 Then
            MessageBox.Show("End of file Encountered!!!")
            CurrentRow = Maxrecord
        End If
        ShowRecord(CurrentRow)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        CurrentRow = CurrentRow - 1
        If CurrentRow = -1 Then
            MessageBox.Show("Beginning of file Encountered!!!")
            CurrentRow = 0
        End If
        ShowRecord(CurrentRow)
    End Sub
End Class
