﻿Public Class Form1
    Dim cn As New OleDb.OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim ds As New DataSet
    Dim Maxrecord As Integer
    Dim CurrentRow As Integer
    'create an array of datarows 
    ' so the result of select method can live in this array
    Dim foundRows() As Data.DataRow
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BooksNewDataSet.BooksTable' table. You can move, or remove it, as needed.
        Me.BooksTableTableAdapter1.Fill(Me.BooksNewDataSet.BooksTable)
        'TODO: This line of code loads data into the 'BooksDataSet.BooksTable' table. You can move, or remove it, as needed.
        'Me.BooksTableTableAdapter.Fill(Me.BooksDataSet.BooksTable)

        cn.ConnectionString = "Provider = SQLNCLI11;Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Downloads\MSSQLVB\MSSQLVB\BooksNew.mdf;Integrated Security=SSPI"
        cn.Open()
        'My Connection is Established
        Dim SqlStr As String
        SqlStr = "Select * from Bookstable"
        da = New OleDb.OleDbDataAdapter(SqlStr, cn)
        da.Fill(ds, "Bookstable")
        Maxrecord = ds.Tables("Bookstable").Rows.Count - 1
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CurrentRow = 0
        Call ShowRecord(CurrentRow)
    End Sub
    Public Sub ShowRecord(ByVal ThisRow As Integer)
        TextBox1.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(0)
        TextBox2.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(1)
        TextBox3.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(2)
        TextBox4.Text = ds.Tables("Bookstable").Rows(ThisRow).Item(3)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CurrentRow = Maxrecord
        ShowRecord(CurrentRow)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        CurrentRow = CurrentRow + 1
        If CurrentRow = Maxrecord + 1 Then
            MessageBox.Show("End of file Encountered!!!")
            CurrentRow = Maxrecord
        End If
        ShowRecord(CurrentRow)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        CurrentRow = CurrentRow - 1
        If CurrentRow = -1 Then
            MessageBox.Show("Beginning of file Encountered!!!")
            CurrentRow = 0
        End If
        ShowRecord(CurrentRow)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Call ClearBoxes()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim Criteria As String
        If TextBox1.Text = "" Then
            MessageBox.Show("Please Enter a Valid ISBN to find")
            Exit Sub ' = return
        End If
        Criteria = "ISBN =" + TextBox1.Text
        foundRows = ds.Tables("Bookstable").Select(Criteria)
        If foundRows.Length = 0 Then 'if the array is empty
            'which it means record not found 
            MessageBox.Show("Record not found !!!")
            Exit Sub
        Else
            'record has been found 
            CurrentRow = ds.Tables("Bookstable").Rows.IndexOf(foundRows(0))
            TextBox1.Text = foundRows(0).Item(0)
            TextBox2.Text = foundRows(0).Item(1)
            TextBox3.Text = foundRows(0).Item(2)
            TextBox4.Text = foundRows(0).Item(3)
            'you can also use the following line instead of the above 4 lines 
            'Call ShowRecord(CurrentRow)
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim Criteria As String
        If TextBox2.Text = "" Then
            MessageBox.Show("Please Enter a Title to find")
            Exit Sub ' = return
        End If
        Criteria = "Title ='" + TextBox2.Text + "'"
        foundRows = ds.Tables("Bookstable").Select(Criteria)
        If foundRows.Length = 0 Then 'if the array is empty
            'which it means record not found 
            MessageBox.Show("Record not found !!!")
            Return
        Else
            'record has been found 
            CurrentRow = ds.Tables("Bookstable").Rows.IndexOf(foundRows(0))
            TextBox1.Text = foundRows(0).Item(0)
            TextBox2.Text = foundRows(0).Item(1)
            TextBox3.Text = foundRows(0).Item(2)
            TextBox4.Text = foundRows(0).Item(3)
            'you can also use the following line instead of the above 4 lines 
            'Call ShowRecord(CurrentRow)
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim Criteria As String
        If TextBox1.Text = "" Then
            MessageBox.Show("Please Enter an ISBN to Add")
            Exit Sub
        End If
        If TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
            MessageBox.Show("Incomplete Data, please fill all fields")
            Exit Sub
        End If
        Criteria = "ISBN =" + TextBox1.Text
        foundRows = ds.Tables("Bookstable").Select(Criteria)
        If foundRows.Length = 0 Then
            Dim NewRow As DataRow = ds.Tables("Bookstable").NewRow()
            'the next line is needed so VB Can execute the SQL statement 
            Dim Cb As New OleDb.OleDbCommandBuilder(da)
            NewRow.Item("ISBN") = Convert.ToInt32(TextBox1.Text)
            NewRow.Item("Title") = TextBox2.Text
            NewRow.Item("Author") = TextBox3.Text
            NewRow.Item("Category") = TextBox4.Text

            ds.Tables.Item("Bookstable").Rows.Add(NewRow)
            da.Update(ds, "Bookstable")
            Maxrecord = Maxrecord + 1
            MessageBox.Show("Record Added succesfully!!!")
        Else
            MessageBox.Show("Duplicate Record!!!, Try another ISBN")
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim Strtofind As String
        If TextBox1.Text = "" Then
            MessageBox.Show("Please Enter a Valid ISBN to find")
            Exit Sub
        End If
        Strtofind = "ISBN =" + TextBox1.Text
        foundRows = ds.Tables("Bookstable").Select(Strtofind)
        Dim RowIndex As Integer
        If foundRows.Length = 0 Then
            MessageBox.Show("Record Not Found, try again")
        Else
            'save the data 
            Dim Cb As New OleDb.OleDbCommandBuilder(da)
            RowIndex = ds.Tables("Bookstable").Rows.IndexOf(foundRows(0))
            ds.Tables("Bookstable").Rows(RowIndex).Item(0) = TextBox1.Text
            ds.Tables("Bookstable").Rows(RowIndex).Item(1) = TextBox2.Text
            ds.Tables("Bookstable").Rows(RowIndex).Item(2) = TextBox3.Text
            ds.Tables("Bookstable").Rows(RowIndex).Item(3) = TextBox4.Text
            da.Update(ds, "Bookstable")
            MessageBox.Show("Record Modified Succesfully")
        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Dim Strtofind As String
        If TextBox1.Text = "" Then
            MessageBox.Show("Please Enter a ISBN to delete")
            Exit Sub
        End If
        Strtofind = "ISBN =" + TextBox1.Text
        foundRows = ds.Tables("Bookstable").Select(Strtofind)
        Dim RowIndex As Integer
        If foundRows.Length = 0 Then
            MessageBox.Show("Record Not Found, try another ISBN")
        Else
            'Delete the data 
            Dim Cb As New OleDb.OleDbCommandBuilder(da)
            Dim result As Integer
            RowIndex = ds.Tables("Bookstable").Rows.IndexOf(foundRows(0))
            Call ShowRecord(RowIndex)
            result = MessageBox.Show("Are you Sure?", "Deleting Record", MessageBoxButtons.YesNo)
            If result = vbYes Then
                ds.Tables("bookstable").Rows(RowIndex).Delete()
                Call ClearBoxes()
                MessageBox.Show("Record deleted Succesfully!!!")
                Maxrecord = Maxrecord - 1
            End If
        End If
    End Sub
    Public Sub ClearBoxes()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
    End Sub
End Class
