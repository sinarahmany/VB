﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    'Add to list button
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If taskBar.Text = "" Then
            statusMessage.ForeColor = Color.Red
            statusMessage.Text = "please type your task before click"
        Else

            Dim task As String = taskBar.Text
            'task = LTrim(RTrim(task))
            task = Trim(task)
            todoList.Items.Add(task + "    Time : " + Format(Now, "hh:mm").ToString)
            taskBar.Clear()
            statusMessage.Text = "please Type your task And hit the botton"
            statusMessage.ForeColor = Color.White
        End If



    End Sub


    'delete button
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


    End Sub
End Class
