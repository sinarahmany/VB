﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load




    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'my code will run
        Dim name As String = "John Doe"
        Dim money As Double = 1004546.79
        Dim isAlive As Boolean = True
        Dim age As Integer = 24 '4 bytes 0 - 255
        Dim initial As Char = "J"
        Dim birthDate As Date = "11/20/1995"
        Dim formattedBirthDate As String = Format(birthDate, "MMM, dd/yyyy")
        Dim rightNow As Date = Date.Now
        Dim formattedDate As String = Format(rightNow, "MMM, dd/yyyy h:m")

        RichTextBox1.Text += "Name : " + name + vbCrLf
        RichTextBox1.Text += "Account Balance : " + money.ToString + Chr(13)
        RichTextBox1.Text += "Is alive? : " + isAlive.ToString + vbCrLf
        RichTextBox1.Text += "Age : " + age.ToString + vbCrLf
        RichTextBox1.Text += "Initial : " + initial.ToString + vbCrLf
        RichTextBox1.Text += "Birth date : " + formattedBirthDate + vbCrLf
        RichTextBox1.Text += "Today : " + formattedDate + vbCrLf

    End Sub
End Class
