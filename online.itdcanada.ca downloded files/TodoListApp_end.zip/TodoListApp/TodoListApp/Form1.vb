﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TabControl1.SelectTab(TabPage2)
        TabControl1.SelectTab(1)
    End Sub

    'add to the list
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If taskBar.Text = "" Then
            statusMessage.Text = "please type your task and hit the botton"
            statusMessage.ForeColor = Color.Red
        Else
            Dim task As String = taskBar.Text
            'task = LTrim(RTrim(task))
            task = Trim(task)
            todoList.Items.Add(task + "    Time : " + Format(Now, "hh:mm").ToString)
            taskBar.Clear()
            statusMessage.Text = "please type your task and hit the botton"
            statusMessage.ForeColor = Color.White
        End If
    End Sub

    'clear all button
    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        'check if the list is empty
        Dim listCounter As Integer = todoList.Items.Count

        If listCounter > 0 Then
            'ask are you sure message
            DialogResult = MessageBox.Show("Are you sure you want to delete ALL?", "WARNING", MessageBoxButtons.YesNo)

            If DialogResult.ToString = "Yes" Then
                todoList.Items.Clear()
                statusMessage.Text = "to do list cleared"
                statusMessage.ForeColor = Color.Red
            Else
                'no action
            End If
        Else
            statusMessage.Text = "List is empty"
            statusMessage.ForeColor = Color.Red
        End If
    End Sub

    'Delete button
    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click

        '                        != not equal 
        If todoList.SelectedItem <> "" Then
            'selected
            DialogResult = MessageBox.Show("are you sure you want to delete this?", "WARNING", MessageBoxButtons.OKCancel)

            If DialogResult.ToString = "OK" Then
                todoList.Items.Remove(todoList.SelectedItem)
                statusMessage.Text = "item deleted successfully"
            Else
                'no action
            End If
        Else
            'not selected
            statusMessage.Text = "Select an item first!"
            statusMessage.ForeColor = Color.Red
        End If

    End Sub

    Private Sub taskBar_TextChanged_1(sender As Object, e As EventArgs) Handles taskBar.TextChanged
        statusMessage.Text = "please type your task and hit the botton"
        statusMessage.ForeColor = Color.White
    End Sub
End Class
