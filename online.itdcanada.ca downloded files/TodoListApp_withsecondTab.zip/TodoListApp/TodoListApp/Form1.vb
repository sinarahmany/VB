﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TabControl1.SelectTab(TabPage2)
        TabControl1.SelectTab(1)
    End Sub

    'add to the list
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If taskBar.Text = "" Then
            statusMessage.Text = "please type your task and hit the botton"
            statusMessage.ForeColor = Color.Red
        Else
            Dim task As String = taskBar.Text
            'task = LTrim(RTrim(task))
            task = Trim(task)
            todoList.Items.Add(task + "    Time : " + Format(Now, "hh:mm").ToString)
            taskBar.Clear()
            statusMessage.Text = "please type your task and hit the botton"
            statusMessage.ForeColor = Color.White
        End If
    End Sub

    'clear all button
    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        'check if the list is empty
        Dim listCounter As Integer = todoList.Items.Count

        If listCounter > 0 Then
            'ask are you sure message
            DialogResult = MessageBox.Show("Are you sure you want to delete ALL?", "WARNING", MessageBoxButtons.YesNo)

            If DialogResult.ToString = "Yes" Then
                todoList.Items.Clear()
                statusMessage.Text = "to do list cleared"
                statusMessage.ForeColor = Color.Red
            Else
                'no action
            End If
        Else
            statusMessage.Text = "List is empty"
            statusMessage.ForeColor = Color.Red
        End If
    End Sub

    'Delete button
    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click

        '                        != not equal 
        If todoList.SelectedItem <> "" Then
            'selected
            DialogResult = MessageBox.Show("are you sure you want to delete this?", "WARNING", MessageBoxButtons.OKCancel)

            If DialogResult.ToString = "OK" Then
                todoList.Items.Remove(todoList.SelectedItem)
                statusMessage.Text = "item deleted successfully"
            Else
                'no action
            End If
        Else
            'not selected
            statusMessage.Text = "Select an item first!"
            statusMessage.ForeColor = Color.Red
        End If

    End Sub

    Private Sub taskBar_TextChanged_1(sender As Object, e As EventArgs) Handles taskBar.TextChanged
        statusMessage.Text = "please type your task and hit the botton"
        statusMessage.ForeColor = Color.White
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        For index = 1 To 10 Step +1
            'RichTextBox1.Text = RichTextBox1.Text + index.ToString + vbCrLf
            RichTextBox1.Text += index.ToString + vbCrLf
        Next

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If IsNumeric(input1.Text) And IsNumeric(input2.Text) Then
            Dim userInput1 As Integer = Convert.ToInt64(input1.Text)
            Dim userInput2 As Integer = Convert.ToInt64(input2.Text)

            If userInput1 < userInput2 Then
                'userinput 1 is greater
                RichTextBox1.Text = "the min value is : " + userInput1.ToString
            Else
                'userinput 2 is greater
                RichTextBox1.Text = "the min value is : " + userInput2.ToString
            End If
        Else
            MessageBox.Show("not number!!")
        End If

    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs)
        'ten times my name

        For index = 1 To 10
            RichTextBox1.Text += "Saygin" + vbCrLf
        Next

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click

        Dim sum As Integer = 0

        For index = 1 To 100 Step +1
            sum += index
        Next

        RichTextBox1.Text = "for loop result : " + sum.ToString
    End Sub



    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        For index = 10 To 1 Step -1
            'RichTextBox1.Text = RichTextBox1.Text + index.ToString + vbCrLf
            RichTextBox1.Text += index.ToString + vbCrLf

        Next

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        If IsNumeric(input1.Text) And IsNumeric(input2.Text) Then
            Dim userInput1 As Integer = Convert.ToInt64(input1.Text)
            Dim userInput2 As Integer = Convert.ToInt64(input2.Text)

            If userInput1 > userInput2 Then
                'userinput 1 is greater
                RichTextBox1.Text = "the max value is : " + userInput1.ToString
            Else
                'userinput 2 is greater
                RichTextBox1.Text = "the max value is : " + userInput2.ToString
            End If
        Else
            MessageBox.Show("not number!!")
        End If

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click

        Dim index As Integer = 0

        While index <= 100

            If index Mod 2 = 0 Then
                RichTextBox1.Text += index.ToString + " "

            End If

            index += 1

        End While

    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click

    End Sub

    Private Sub Button13_Click_1(sender As Object, e As EventArgs) Handles Button13.Click

        Dim sum As Integer = 0
        Dim index As Integer = 1

        Do
            sum += index
            index += 1
        Loop Until index > 100


        RichTextBox1.Text = "Do loop result : " + sum.ToString


    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click

        Dim sum As Integer = 0
        Dim index As Integer = 1

        While index <= 100
            sum += index
            index += 1
        End While

        RichTextBox1.Text = "While loop result : " + sum.ToString

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click

        ' 1 3 5 7 9 11 .... 99
        Dim index As Integer = 0

        While index <= 100

            If index Mod 2 = 1 Then
                RichTextBox1.Text += index.ToString + " "

            End If

            index += 1

        End While

    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        RichTextBox1.Clear()
    End Sub
End Class
