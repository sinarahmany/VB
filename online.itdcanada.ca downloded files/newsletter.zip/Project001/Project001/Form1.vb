﻿Public Class Form1


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'MessageBox.Show("alert!!!!")

        Dim email As String = TextBox1.Text
        'check if there the email is empty

        If email Is "" Then
            'MessageBox.Show("your email is missing!")
            Label3.Text = "oops you forgot to type your email!"
        Else
            Label3.Text = "Thank you, your email is: " + email
            TextBox1.Text = ""
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
