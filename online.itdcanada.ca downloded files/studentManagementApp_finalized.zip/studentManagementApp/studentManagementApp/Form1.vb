﻿Public Class Form1

    Dim conObj As New ADODB.Connection
    Dim recSetObj As New ADODB.Recordset
    Dim initilizetoggle As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conObj.Provider = "Microsoft.ACE.OLEDB.12.0"
        conObj.ConnectionString = "../../StudentsInfo.accdb"
        conObj.Open()
        recSetObj.Open("SELECT * FROM Students",
                       conObj,
                       ADODB.CursorTypeEnum.adOpenDynamic,
                       ADODB.LockTypeEnum.adLockOptimistic)
        studentStartDateBox.Format = DateTimePickerFormat.Custom
        studentStartDateBox.CustomFormat = "MMM,d yyyy"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles firstButton.Click
        recSetObj.MoveFirst()
        showData()
        clearError()
        checkAndChangeFieldBackgroundColor()
    End Sub

    Private Sub RadioButtonMan_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonMan.CheckedChanged
        manAvatar.BringToFront()
        manAvatar.BackColor = Color.White
    End Sub

    Private Sub RadioButtonWoman_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonWoman.CheckedChanged
        womanAvatar.BringToFront()
        womanAvatar.BackColor = Color.White
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles nextButton.Click
        recSetObj.MoveNext()
        If recSetObj.EOF Then
            recSetObj.MoveLast()
            showData()
            printError("No more records. End of records.")
            checkAndChangeFieldBackgroundColor()
        Else
            showData()
            clearError()
            checkAndChangeFieldBackgroundColor()
        End If
    End Sub




    Private Sub lastButton_Click(sender As Object, e As EventArgs) Handles lastButton.Click
        recSetObj.MoveLast()
        showData()
        clearError()
        checkAndChangeFieldBackgroundColor()
    End Sub



    Private Sub prevButton_Click_1(sender As Object, e As EventArgs) Handles prevButton.Click

        recSetObj.MovePrevious()
        If recSetObj.BOF Then
            recSetObj.MoveFirst()
            showData()
            printError("No more records. Begining of records.")
            checkAndChangeFieldBackgroundColor()
        Else
            showData()
            clearError()
            checkAndChangeFieldBackgroundColor()
        End If
    End Sub

    Private Sub clearButton_Click(sender As Object, e As EventArgs) Handles clearButton.Click
        clearAllBoxes()
        studentNameBox.BackColor = Color.White
        studentLastNameBox.BackColor = Color.White
        studentNumberBox.BackColor = Color.White
        studentStartDateBox.BackColor = Color.White
        studentProgramBox.BackColor = Color.White
        studentAddressBox.BackColor = Color.White
        studentPhoneBox.BackColor = Color.White
        studentEmailBox.BackColor = Color.White
        studentCountryBox.BackColor = Color.White
        womanAvatar.BackColor = Color.White
        manAvatar.BackColor = Color.White
    End Sub

    Sub showData()

        studentNameBox.Text = recSetObj.Fields("StudentName").Value.ToString
        studentLastNameBox.Text = recSetObj.Fields("StudentLastName").Value.ToString.ToUpper
        studentNumberBox.Text = recSetObj.Fields("StudentNumber").Value.ToString
        studentStartDateBox.Text = recSetObj.Fields("StartDate").Value
        studentProgramBox.Text = recSetObj.Fields("Program").Value.ToString
        studentAddressBox.Text = recSetObj.Fields("Address").Value.ToString
        studentPhoneBox.Text = recSetObj.Fields("PhoneNumber").Value.ToString
        studentEmailBox.Text = recSetObj.Fields("Email").Value.ToString
        studentCountryBox.Text = recSetObj.Fields("Country").Value.ToString


        Dim gender As Boolean = recSetObj.Fields("Gender").Value.ToString
        If gender Then
            RadioButtonMan.Checked = True
        Else
            RadioButtonWoman.Checked = True
        End If
    End Sub

    Sub printError(message As String)
        errorMessage.Text = message
    End Sub
    Sub clearError()
        errorMessage.Text = ""
    End Sub

    Sub clearAllBoxes()
        studentNameBox.Clear()
        studentLastNameBox.Clear()
        studentNumberBox.Clear()
        studentStartDateBox.ResetText()
        studentProgramBox.Clear()
        studentAddressBox.Clear()
        studentPhoneBox.Clear()
        studentEmailBox.Clear()
        studentCountryBox.Clear()
        RadioButtonMan.Checked = False
        RadioButtonWoman.Checked = False

        clearError()

        searchBox.Clear()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles searchButton.Click

        If Not radioButtonByEmail.Checked And Not radioButtonByStudentId.Checked Then
            radioButtonByEmail.ForeColor = Color.Red
            radioButtonByEmail.Font = New Font(radioButtonByEmail.Font, FontStyle.Bold)
            radioButtonByStudentId.ForeColor = Color.Red
            radioButtonByStudentId.Font = New Font(radioButtonByStudentId.Font, FontStyle.Bold)
            Exit Sub
        End If


        radioButtonByEmail.Font = New Font(radioButtonByEmail.Font, FontStyle.Regular)
        radioButtonByStudentId.Font = New Font(radioButtonByStudentId.Font, FontStyle.Regular)

        radioButtonByEmail.ForeColor = Color.Black
        radioButtonByStudentId.ForeColor = Color.Black


        recSetObj.MoveFirst()
        Dim StrCriteria As String

        If radioButtonByEmail.Checked Then
            StrCriteria = "Email = '" + searchBox.Text + "'"
            recSetObj.Find(StrCriteria)
        End If

        If radioButtonByStudentId.Checked Then
            StrCriteria = "StudentNumber = '" + searchBox.Text + "'"
            recSetObj.Find(StrCriteria)
        End If


        If recSetObj.EOF Then 'I did not find the record 
            clearAllBoxes()
            printError("Record not found, Please try again")
        Else 'record is found 
            showData()
            printError("")
        End If

    End Sub

    Private Sub Button1_Click_2(sender As Object, e As EventArgs) Handles Button1.Click

        If Not initilizetoggle Then
            initilizedValues()
            initilizetoggle = True
            Exit Sub
        End If



        If isFormEmpty() Then
            checkAndChangeFieldBackgroundColor()
            printError("Some fields are empty, adding failed")
            Exit Sub
        End If


        checkAndChangeFieldBackgroundColor()
        clearError()

        If Not checkDuplicate() Then
            Exit Sub
        End If

        'record is found no duplicates 
        recSetObj.AddNew()
        SaveInAccessFile()
        recSetObj.Update()
        clearAllBoxes()
        printError("New record saved succesfully!")
        initilizetoggle = False


    End Sub

    Sub SaveInAccessFile()
        recSetObj.Fields("StudentName").Value = studentNameBox.Text
        recSetObj.Fields("StudentLastName").Value = studentLastNameBox.Text
        recSetObj.Fields("StudentNumber").Value = studentNumberBox.Text
        recSetObj.Fields("StartDate").Value = studentStartDateBox.Text
        recSetObj.Fields("Program").Value = studentProgramBox.Text
        recSetObj.Fields("Address").Value = studentAddressBox.Text
        recSetObj.Fields("PhoneNumber").Value = studentPhoneBox.Text
        recSetObj.Fields("Email").Value = studentEmailBox.Text
        recSetObj.Fields("Country").Value = studentCountryBox.Text

        If RadioButtonMan.Checked Then
            recSetObj.Fields("Gender").Value = True
        Else
            recSetObj.Fields("Gender").Value = False
        End If

    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click

        If isFormEmpty() Then
            checkAndChangeFieldBackgroundColor()
            printError("Some fields are empty, deleting failed")
            Exit Sub
        End If

        checkAndChangeFieldBackgroundColor()

        recSetObj.MoveFirst()
        Dim StrCriteria As String
        StrCriteria = "StudentNumber = '" + studentNumberBox.Text + "'"
        recSetObj.Find(StrCriteria)


        If recSetObj.EOF Then 'I did not find the record 
            printError("Record not found, check the student ID")
        Else 'record is found 

            Dim Msgboxresult As MessageBoxButtons

            Dim gender As String
            If recSetObj.Fields("Gender").Value Then
                gender = "Male"
            Else
                gender = "Female"
            End If

            Dim messageboxMessage As String = "Following contact information with Student Id : #" + studentNumberBox.Text + vbCrLf + " Are you sure you want to delete this data perminantly?" + vbCrLf + vbCrLf +
                                    "StudentName : " + recSetObj.Fields("StudentName").Value.ToString + vbCrLf +
                                    "StudentLastName : " + recSetObj.Fields("StudentLastName").Value.ToString + vbCrLf +
                                    "StartDate : " + recSetObj.Fields("StartDate").Value.ToString + vbCrLf +
                                    "Program : " + recSetObj.Fields("Program").Value.ToString + vbCrLf +
                                    "Address : " + recSetObj.Fields("Address").Value.ToString + vbCrLf +
                                    "PhoneNumber : " + recSetObj.Fields("PhoneNumber").Value.ToString + vbCrLf +
                                    "Email : " + recSetObj.Fields("Email").Value.ToString + vbCrLf +
                                    "Country : " + recSetObj.Fields("Country").Value.ToString + vbCrLf +
                                    "Gender : " + gender + vbCrLf

            Msgboxresult = MessageBox.Show(messageboxMessage, "WARNING", MessageBoxButtons.YesNo)
            If Msgboxresult = vbYes Then
                recSetObj.Delete()
                recSetObj.Update()
                clearAllBoxes()
                printError("Record deleted succesfully!")

            Else
                'Changed my mind, Don't want to delete
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If isFormEmpty() Then
            checkAndChangeFieldBackgroundColor()
            printError("Some fields are empty, updating failed")
            Exit Sub
        End If


        If isFormEqualsToRecord() Then
            printError("Nothing to update")
            Exit Sub
        End If

        checkAndChangeFieldBackgroundColor()

        recSetObj.MoveFirst()
        Dim StrCriteria As String
        StrCriteria = "StudentNumber = '" + studentNumberBox.Text + "'"
        recSetObj.Find(StrCriteria)


        If recSetObj.EOF Then 'I did not find the record 
            printError("Record not found, check the student ID")
        Else 'record is found 
            Dim Msgboxresult As MessageBoxButtons
            'fix
            Dim gender As String
            If RadioButtonMan.Checked Then
                gender = "Male"
            Else
                gender = "Female"
            End If




            Dim messageboxMessage As String = "Following contact information with Student Id : #" + studentNumberBox.Text + vbCrLf + " will be UPDATED in the system with the following data" + vbCrLf + " Are you sure you want to UPDATE this data?" + vbCrLf + vbCrLf +
                                    "StudentName : " + studentNameBox.Text + vbCrLf +
                                    "StudentLastName : " + studentLastNameBox.Text + vbCrLf +
                                    "StartDate : " + Format(studentStartDateBox.Value, "MMM d, YYYY") + vbCrLf +
                                    "Program : " + studentProgramBox.Text + vbCrLf +
                                    "Address : " + studentAddressBox.Text + vbCrLf +
                                    "PhoneNumber : " + studentPhoneBox.Text + vbCrLf +
                                    "Email : " + studentEmailBox.Text + vbCrLf +
                                    "Country : " + studentCountryBox.Text + vbCrLf +
                                    "Gender : " + gender + vbCrLf


            Msgboxresult = MessageBox.Show(messageboxMessage, "WARNING", MessageBoxButtons.YesNo)
            If Msgboxresult = vbYes Then
                SaveInAccessFile()
                printError("Record updated successfully")
            End If
        End If


    End Sub

    Sub checkAndChangeFieldBackgroundColor()
        If studentNameBox.Text = "" Then studentNameBox.BackColor = Color.LightCoral Else studentNameBox.BackColor = Color.White
        If studentLastNameBox.Text = "" Then studentLastNameBox.BackColor = Color.LightCoral Else studentLastNameBox.BackColor = Color.White
        If studentNumberBox.Text = "" Then studentNumberBox.BackColor = Color.LightCoral Else studentNumberBox.BackColor = Color.White
        If studentStartDateBox.Text = "" Then studentStartDateBox.BackColor = Color.LightCoral Else studentStartDateBox.BackColor = Color.White
        If studentProgramBox.Text = "" Then studentProgramBox.BackColor = Color.LightCoral Else studentProgramBox.BackColor = Color.White
        If studentAddressBox.Text = "" Then studentAddressBox.BackColor = Color.LightCoral Else studentAddressBox.BackColor = Color.White
        If studentPhoneBox.Text = "" Then studentPhoneBox.BackColor = Color.LightCoral Else studentPhoneBox.BackColor = Color.White
        If studentEmailBox.Text = "" Then studentEmailBox.BackColor = Color.LightCoral Else studentEmailBox.BackColor = Color.White
        If studentCountryBox.Text = "" Then studentCountryBox.BackColor = Color.LightCoral Else studentCountryBox.BackColor = Color.White

        If (Not RadioButtonMan.Checked And Not RadioButtonWoman.Checked) Then
            womanAvatar.BackColor = Color.LightCoral
            manAvatar.BackColor = Color.LightCoral
        Else
            womanAvatar.BackColor = Color.White
            manAvatar.BackColor = Color.White
        End If
    End Sub




    Function isFormEmpty()

        If studentNameBox.Text = "" Or
           studentLastNameBox.Text = "" Or
           studentNumberBox.Text = "" Or
           studentStartDateBox.Text = "" Or
           studentProgramBox.Text = "" Or
           studentAddressBox.Text = "" Or
           studentPhoneBox.Text = "" Or
           studentEmailBox.Text = "" Or
           studentCountryBox.Text = "" Or
           (Not RadioButtonMan.Checked And
           Not RadioButtonWoman.Checked) Then

            Return True

        End If

        Return False

    End Function


    Function checkDuplicate()
        recSetObj.MoveFirst()
        Dim StrCriteria As String
        StrCriteria = "StudentNumber ='" + studentNumberBox.Text + "'"
        recSetObj.Find(StrCriteria)
        If Not recSetObj.EOF Then 'I did not find the record 
            printError("Duplicate record (Student ID), Please try again")
            Return False
        End If

        recSetObj.MoveFirst()
        StrCriteria = "Email ='" + studentEmailBox.Text + "'"
        recSetObj.Find(StrCriteria)
        If Not recSetObj.EOF Then 'I did not find the record 
            printError("Duplicate record (Email), Please try again")
            Return False
        End If

        recSetObj.MoveFirst()
        StrCriteria = "PhoneNumber ='" + studentPhoneBox.Text + "'"
        recSetObj.Find(StrCriteria)
        If Not recSetObj.EOF Then 'I did not find the record 
            printError("Duplicate record (Phone Number), Please try again")
            Return False
        End If

        Return True
    End Function

    'Private Sub studentNameBox_TextChanged(sender As Object, e As EventArgs) Handles studentNameBox.TextChanged, studentNameBox.TextChanged, studentLastNameBox.TextChanged, studentNumberBox.TextChanged, studentProgramBox.TextChanged, studentAddressBox.TextChanged, studentPhoneBox.TextChanged, studentEmailBox.TextChanged, studentCountryBox.TextChanged

    '    If (DirectCast(sender, TextBox).Text IsNot "") Then
    '        DirectCast(sender, TextBox).BackColor = Color.White
    '    Else
    '        DirectCast(sender, TextBox).BackColor = Color.LightCoral
    '    End If


    'End Sub

    Function isFormEqualsToRecord() As Boolean

        recSetObj.MoveFirst()
        Dim StrCriteria As String = "StudentNumber = '" + studentNumberBox.Text + "'"
        recSetObj.Find(StrCriteria)

        Dim gender As Boolean

        If RadioButtonMan.Checked Then
            gender = True
        Else
            gender = False
        End If

        If recSetObj.Fields("StudentName").Value.ToString = studentNameBox.Text And
            recSetObj.Fields("StudentLastName").Value.ToString.ToUpper = studentLastNameBox.Text And
            recSetObj.Fields("StudentNumber").Value.ToString = studentNumberBox.Text And
            recSetObj.Fields("Program").Value.ToString = studentProgramBox.Text And
            recSetObj.Fields("Address").Value.ToString = studentAddressBox.Text And
            recSetObj.Fields("PhoneNumber").Value.ToString = studentPhoneBox.Text And
            recSetObj.Fields("Email").Value.ToString = studentEmailBox.Text And
            recSetObj.Fields("Country").Value.ToString = studentCountryBox.Text Then
            'recSetObj.Fields("Gender").Value.ToString = gender.ToString And
            'recSetObj.Fields("StartDate").Value.ToString = studentStartDateBox.Text Then


            Return True
        Else
            Return False
        End If

    End Function

    Sub initilizedValues()
        studentNameBox.Text = "Name"
        studentLastNameBox.Text = "Last Name"
        studentNumberBox.Text = "#### ####"
        studentStartDateBox.Text = "Jan 2, 2019"
        studentProgramBox.Text = "Program name"
        studentAddressBox.Text = "City"
        studentPhoneBox.Text = "phone number"
        studentEmailBox.Text = "email"
        studentCountryBox.Text = "Country"
        RadioButtonWoman.Checked = True

        initilizetoggle = True

    End Sub


End Class
