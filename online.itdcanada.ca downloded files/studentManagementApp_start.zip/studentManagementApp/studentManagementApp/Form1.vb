﻿Public Class Form1

    Dim conObj As New ADODB.Connection
    Dim recSetObj As New ADODB.Recordset

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conObj.Provider = "Microsoft.ACE.OLEDB.12.0"
        conObj.ConnectionString = "./StudentsInfo.accdb"
        conObj.Open()
        recSetObj.Open("SELECT * FROM Students",
                       conObj,
                       ADODB.CursorTypeEnum.adOpenDynamic,
                       ADODB.LockTypeEnum.adLockOptimistic)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles firstButton.Click
        recSetObj.MoveFirst()
        showData()
        clearOutputMessage()
    End Sub

    Private Sub RadioButtonMan_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonMan.CheckedChanged
        manAvatar.BringToFront()
    End Sub

    Private Sub RadioButtonWoman_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonWoman.CheckedChanged
        womanAvatar.BringToFront()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles nextButton.Click
        recSetObj.MoveNext()
        If recSetObj.EOF Then
            recSetObj.MoveLast()
            showData()
            outputMessage("No more records. End of records.")
        Else
            showData()
            clearOutputMessage()
        End If
    End Sub


    Private Sub clearButton_Click(sender As Object, e As EventArgs) Handles clearButton.Click
        clearAllBoxes()
    End Sub

    Sub showData()

        studentNameBox.Text = recSetObj.Fields("StudentName").Value.ToString
        studentLastNameBox.Text = recSetObj.Fields("StudentLastName").Value.ToString.ToUpper
        studentNumberBox.Text = recSetObj.Fields("StudentNumber").Value.ToString
        studentStartDateBox.Text = Format(recSetObj.Fields("StartDate").Value, "MMM,d yyyy")
        studentProgramBox.Text = recSetObj.Fields("Program").Value.ToString
        studentAddressBox.Text = recSetObj.Fields("Address").Value.ToString
        studentPhoneBox.Text = recSetObj.Fields("PhoneNumber").Value.ToString
        studentEmailBox.Text = recSetObj.Fields("Email").Value.ToString
        studentCountryBox.Text = recSetObj.Fields("Country").Value.ToString

        Dim gender As Boolean = recSetObj.Fields("Gender").Value.ToString
        If gender Then
            RadioButtonMan.Checked = True
        Else
            RadioButtonWoman.Checked = True
        End If
    End Sub

    Sub outputMessage(message As String)
        userMessage.Text = message
    End Sub
    Sub clearOutputMessage()
        userMessage.Text = ""
    End Sub

    Sub clearAllBoxes()
        studentNameBox.Clear()
        studentLastNameBox.Clear()
        studentNumberBox.Clear()
        studentStartDateBox.Clear()
        studentProgramBox.Clear()
        studentAddressBox.Clear()
        studentPhoneBox.Clear()
        studentEmailBox.Clear()
        studentCountryBox.Clear()
        RadioButtonMan.Checked = False
        RadioButtonWoman.Checked = False

        clearOutputMessage()
    End Sub




End Class
